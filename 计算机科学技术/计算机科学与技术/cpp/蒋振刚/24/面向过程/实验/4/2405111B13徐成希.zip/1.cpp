#include<bits/stdc++.h>
using namespace std;
int a[100];
int zhishu(int n){
    if(n==1){
        return 0;
    }
    for(int i=2;i<=sqrt(n);i++){
        if(n%i==0){
            return 0;
        }
    }
    return 1;
}
int main(){
    int n;
    cin>>n;
    for(int i=2;i<=(n/2);i++){
        if(zhishu(i)==1 and zhishu(n-i)==1){
            cout<<i<<" "<<n-i;
            break;
        }
    }
}
