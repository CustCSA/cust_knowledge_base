#include<bits/stdc++.h>
using namespace std;
int main()
{
    int i;
    cin>>i;
    if((i%4==0 and i%100!=0) or i%400==0)
    {
        cout<<"����";
    }
    else{
        cout<<"����";
    }
}
