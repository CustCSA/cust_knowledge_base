#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    double a,b,c;
    cin>>a>>b>>c;
    double m=(a+b+c)/2.0;
    double s=sqrt(m*(m-a)*(m-b)*(m-c));
    cout<<s;
}