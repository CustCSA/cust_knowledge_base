#include <stdio.h>
#include <stdlib.h>
typedef struct Node {
    int data;
    struct Node* next;
} Node;
Node* create() {
    Node* head = NULL; 
    Node* tail = NULL; 
    Node* newNode;
    int input;

    printf("������ڵ����ݣ�����1��������\n");
    while (1) {
        scanf("%d", &input);
        if (input == 1) {
            break;
        }
        newNode = (Node*)malloc(sizeof(Node));
        if (!newNode) {
            printf("�ڴ����ʧ�ܣ�\n");
            exit(1); 
        }
        newNode->data = input; 
        newNode->next = NULL; 
        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else { 
            tail->next = newNode;
            tail = newNode;
        }
    }
    Node* current = head;
    printf("�����е����ݣ�\n");
    while (current != NULL) {
        printf("%d -> ", current->data);
        current = current->next;
    }
    printf("NULL\n");

    return head;  
}
void freeList(Node* head) {
    Node* current = head;
    Node* nextNode;

    while (current != NULL) {
        nextNode = current->next; 
        free(current); 
        current = nextNode; 
    }
}
int main() {
    Node* list = create();
    freeList(list); 
    return 0;
}

