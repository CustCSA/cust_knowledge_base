#include <iostream>
#include <vector>
#include <string>

struct Student {
    int num;
    std::string name;
    std::vector<int> score;
};

void print(const std::vector<Student>& students) {
    for (size_t i = 0; i < students.size(); ++i) {
        const Student& student = students[i];
        std::cout << "ѧ��: " << student.num << ", ����: " << student.name << ", �ɼ�: ";
        for (size_t j = 0; j < student.score.size(); ++j) {
            std::cout << (j > 0 ? ", " : "") << student.score[j];
        }
        std::cout << std::endl;
    }
}

int main() { 
    std::vector<Student> students(5);
    for (size_t i = 0; i < students.size(); ++i) {
        std::cout << "�����" << (i + 1) << "��ѧ����ѧ��: ";
        std::cin >> students[i].num;
        std::cout << "�����" << (i + 1) << "��ѧ��������: ";
        std::cin >> students[i].name;
        
        students[i].score.resize(3);
        std::cout << "�����" << (i + 1) << "��ѧ�������ſγɼ�: ";
        for (size_t j = 0; j < 3; ++j) {
            std::cin >> students[i].score[j];
        }
    }
    print(students);
    return 0;
}
