#include<iostream>
using namespace std;
int main()
{
	char *p[]={"Jan.","Feb.","Mar.","Apr.","May","Jun.","Jul.","Aug.","Sep.","Oct.","Nov.","Dec."};
	int n;
	cin>>n;
	if(n<12&&n>-1)
	{
		cout<<*(p+n-1);
	}
	
}
