#include<iostream>
#include<vector>
using namespace std;
int main()
{
	int n;
	cin>>n;
	vector<int> a(n);
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	int *p;
	int m;
	cin>>m;
	for (p=&a[n-m];p<&a[n];p++)
	{
		cout<<*p<<" ";
	}
	for(p=&a[0];p<&a[n-m];p++)
	{
		cout<<*p<<" ";
	}
}
