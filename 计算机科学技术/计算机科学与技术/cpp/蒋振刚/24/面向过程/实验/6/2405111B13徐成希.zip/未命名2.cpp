#include <iostream>
#include <cctype>
#include <string>
int main() {
    std::string input;
    std::getline(std::cin, input);
    int uppercase_count = 0;
    int lowercase_count = 0;
    int space_count = 0;
    int digit_count = 0;
    int other_symbol_count = 0;
 
    for (char ch : input) {
        if (std::isupper(ch)) {
            ++uppercase_count;
        } else if (std::islower(ch)) {
            ++lowercase_count;
        } else if (std::isspace(ch)) {
            ++space_count;
        } else if (std::isdigit(ch)) {
            ++digit_count;
        } else {
            ++other_symbol_count;
        }
    }
    std::cout << "uppercase: " << uppercase_count << std::endl;
    std::cout << "lowercase: " << lowercase_count << std::endl;
    std::cout << "space: " << space_count << std::endl;
    std::cout << "digit: " << digit_count << std::endl;
    std::cout << "other_symbol: " << other_symbol_count << std::endl;
    return 0;
}
