#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
int main() {
    int n;
    std::cin >> n;
    std::vector<std::string> strings(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> strings[i];
    }
    std::sort(strings.begin(), strings.end());
    for (int i = 0; i < n; ++i) {
        std::cout << strings[i] << std::endl;
    }
    return 0;
}
