#include<bits/stdc++.h>
using namespace std;
int main(){
	string a;
	getline(cin,a);
	int lg=a.size();
	for(int i=lg-1;i>=0;i--){
		cout<<a[i];
	}
}
