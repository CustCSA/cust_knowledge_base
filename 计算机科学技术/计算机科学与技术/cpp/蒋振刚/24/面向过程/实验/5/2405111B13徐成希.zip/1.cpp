#include<bits/stdc++.h>
using namespace std;
int op[100][100];
int yanghui(int x,int y){
	if(y==1 or x==y){
		return op[x][y]=1;
	}
	if(op[x][y]==0) {
	return op[x][y]=(op[x-1][y]+op[x-1][y-1]);
	}
}
int main(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			cout<<yanghui(i,j)<<" ";
		}
		cout<<endl;
	}
} 
