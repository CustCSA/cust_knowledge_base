#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a,b,c,d,e;
    cin>>a;
    b=a*2-1;
    for(int i=1;i<=a;i++)
    {
        c=2*i-1;
        d=i-1;
        d=a-d;
        for(int j=d;j>=2;j--){cout<<" ";}
        for(int j=1;j<=c;j++){cout<<"*";}
        cout<<endl;
    }
}