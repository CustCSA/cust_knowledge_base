#include<bits/stdc++.h>
using namespace std;
int main()
{
    char a[50][100];
    for(int i=0;i<50;i++)
    {
        for(int j=0;j<100;j++)
        {
            a[i][j]=' ';
        }
    }
    for(int i=0;i<50;i++)
    {
        int n;
        n=int(25+25*sin(2*3.1415926*i/50));
        a[n][i]='*';
    }
    for(int i=0;i<50;i++)
    {
        for(int j=0;j<100;j++)
        {
            cout<<a[i][j];
        }
        cout<<endl;
    }
}